var express = require('express');
var bodyParser = require('body-parser');
var mongoose=require('mongoose');

var Genre=require('./models/genres.js');
var Books=require('./models/books.js');

mongoose.connect('mongodb://localhost/bookstore');




var app = express();

app.use(express.static(_dirname+'/client'));
app.use(bodyParser.json());


app.get('/',function(req,res){
	    res.send("Please request to /api/books or /api/genres");
})


app.get('/api/genres',function(req,res){
      Genre.getGenres(function(err,genres){
      	   if(err)
      	   	   throw err;
      	   	else
      	   		res.json(genres);
      },0);
})


app.get('/api/books',function(req,res){
      Books.getBooks(function(err,books){
      	   if(err)
      	   	   throw err;
      	   	else
      	   		res.json(books);
      },0);
})

app.get('/api/books/:id',function(req,res){
      Books.getBookById(req.params.id,function(err,book){
      	   if(err)
      	   	   throw err;
      	   	else
      	   		res.json(book);
      });
})




app.post('/api/genres',function(req,res){

	   var genre=req.body;

      Genre.addGenre(genre,function(err,genre){
      	   if(err)
      	   	   throw err;
      	   	else
      	   		res.json(genre);
      });
})


app.post('/api/books',function(req,res){

	   var book=req.body;

      Books.addBook(book,function(err,genre){
      	   if(err)
      	   	   throw err;
      	   	else
      	   		res.json(book);
      });
})




app.put('/api/genres/:id',function(req,res){
       
       var id=req.params.id;
	   var genre=req.body;

      Genre.updateGenre(id,genre,{},function(err,genre){
      	   if(err)
      	   	   throw err;
      	   	else
      	   		res.json(genre);
      });
})



app.put('/api/books/:_id',function(req,res){
       
       var id=req.params._id;
	   var book=req.body;

      Books.updateBook(id,book,{},function(err,book){
      	   if(err)
      	   	   throw err;
      	   	else
      	    {
      	    	 res.json(book);
      	    }
      });
})

app.delete('/api/genres/:id',function(req,res){


	   var id=req.params.id;

      Genre.removeGenre(id,function(err,result){
      	   if(err)
      	   	   throw err;
      	   	if(result)
      	   	{
      	   		 let response = {
                                         message: "Todo successfully deleted",
                                              
                                };
                res.status(200).send(response);
      	   	}
      });
})

app.listen(3000);

console.log("Server is running at Port 3000");


