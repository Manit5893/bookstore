var mongoose=require('mongoose');

var bookSchema = mongoose.Schema({
	   title:{
	   	 type: String,
	   	 required:true
	   },
	   genre:{
	   	  type: String,
	   	  required:true
	   },
	   author:{
	   	type: String
	   },
	   description:{
	   	 type: String
	   },
	   imageurl: {
	   	 type: String
	   },
	   buyurl:{
	   	  type: String
	   },
	   create_date:{
	   	  type: Date,
	   	  default: Date.now
	   }
})


var Books = module.exports = mongoose.model('Books',bookSchema);

module.exports.getBooks = function(callback,limit){

	 Books.find(callback).limit(limit);

}


module.exports.getBookById = function(id,callback){

	 Books.findById(id,callback);

}



module.exports.addBook=function(book,callback){
	     Books.create(book,callback);
}


module.exports.updateBook=function(id,book,options,callback){
	   
	   var query={_id:id}
	   var update={
	   	title:book.title,
	   	genre:book.genre,
	   	author:book.author,
	   	description:book.description,
	   	imageurl:book.imageurl,
	   	buyurl:book.buyurl

	   }
	   Books.findOneAndUpdate(query,update,options,callback);
}